# Carrier Ops — EDMC plugin

Pushes fleet carrier events from your journal to a [Carrier Ops](https://grayflare.space/fc/) board
as they happen, so you never upload a file by hand.

## Install

1. In EDMarketConnector: **File → Settings → Plugins → Open** (this opens your plugins folder).
2. Copy the `CarrierOps` folder into it.
3. Restart EDMC.
4. **File → Settings → Carrier Ops**, paste the API key from the board's
   [settings page](https://grayflare.space/fc/settings.php), and press **Test connection**.

The plugins folder is normally:

```
%LOCALAPPDATA%\EDMarketConnector\plugins
```

## Using it

Once a key is set it runs by itself. The main EDMC window shows a one-line status — `sent 4`,
`up to date`, `offline`, `bad API key`.

- Carrier events are batched and sent every 20 seconds. `CarrierStats`, `CarrierJump`,
  `CarrierJumpRequest`, `CarrierJumpCancelled` and `CarrierLocation` go immediately, because those
  are the ones somebody may be watching the board for.
- `Market.json`, `Shipyard.json` and `Outfitting.json` are read off disk and sent whole whenever the
  game writes one for a carrier — the journal event itself only names the station, the item list
  lives in the file.
- **Upload past journals** in the settings tab scans every journal you still have and sends the
  carrier events out of them. Worth pressing once, after connecting; it will populate years of jump
  history and finances in one go.

Opening the **Carrier Management** screen in game writes a `CarrierStats` event, which carries crew,
finances, fuel, space usage and docking access all at once. It is the single most useful thing to
trigger if the board looks out of date.

## Exact upkeep and the cargo hold

Two things are simply not in the journal: what the game actually charges for upkeep, and what is in
the carrier's hold. Both are in Frontier's Companion API, and the board now holds an approved client
id of its own.

**Connect your Frontier account on the board's settings page.** The upkeep panel switches from
*estimated* to the game's own figures, with a Cargo tab alongside. Because the board asks Frontier
directly, it keeps doing so with the game shut and EDMC closed — which the old route never could.

Nothing in EDMC needs configuring for this any more.

### What changed in 1.4.1

1.4.0 dropped transfers if EDMC had been started while you were already docked at the carrier —
which, since installing it means restarting EDMC, was most of the time. The plugin only knew where
you were from the `Docked` event, and EDMC begins reading the journal where it currently ends, so
that event had already gone past. It now reads the journal for the answer when it does not have one.

### What changed in 1.4.0

Moving cargo on or off a carrier now shows on the board straight away.

It used to wait, and could wait a very long time. The hold has two sources and neither is prompt:
`CarrierStats` carries the tonnage but the game only writes it when you open the carrier management
screen, and the Companion API has the full manifest but runs 10–15 minutes behind. So transferring
1,216 t of tritium off a carrier left the board showing the old figure until one of those two
happened to catch up — which, if you did not open that screen again, could be days.

`CargoTransfer` is the one thing the game reports as it happens, so the plugin now sends it, and the
board applies it immediately and holds the Companion API off until its cache has caught up.

It is applied as a *change* rather than a reading — the event says 1,216 t of tritium moved, not what
the hold now contains. That means it can drift: a transfer made with EDMC closed is never seen, and
the arithmetic assumes it saw everything. The next Companion API sync replaces the whole manifest and
corrects any drift, so this is a good answer for the fifteen minutes before the exact one arrives.
For the same reason **Upload past journals** skips these deliberately — replaying an old transfer
would subtract the same cargo twice.

### What changed in 1.3.0

Earlier versions forwarded each `/fleetcarrier` payload EDMC had fetched, which required
**Enable Fleet Carrier CAPI Queries** in EDMC's *Configuration* tab. That is gone, and the setting no
longer has any effect on this plugin.

It was worth removing rather than merely redundant. Frontier serves that endpoint from a cache which
refreshes every 10–15 minutes, so a forwarded reply could land seconds after the journal had reported
the truth and overwrite it — a tank refuelled to 1000 t reverting to 906 t, once per push. The board
guards against that now, but not sending the stale copy at all is the better fix.

## What it sends

Only fleet carrier events, listed explicitly in `CARRIER_EVENTS` at the top of `load.py`, plus
`CargoTransfer` while you are docked at a carrier. Every other journal entry EDMC hands the plugin is
checked for its event name and then dropped — nothing about where you have been, what you scanned,
who you fought or what was said in chat leaves your machine.

One clarification, since 1.4.0 reads two events it does not send. `CargoTransfer` is written in your
*ship's* journal and names no carrier at all, so the plugin has to know which one you are standing
in: it watches `Docked` and `Location` for the market id, and only when the station is a fleet
carrier. Dock anywhere else and that is cleared, so no starport you visit is recorded or sent. The
transfer itself is only sent while a carrier is what you are docked at.

Snapshot files are only sent when the station is a carrier. `Market.json` says so directly;
`Shipyard.json` and `Outfitting.json` do not carry a station type at all, so the plugin matches the
market id against a carrier it has already seen this session, falling back to the shape of the
station name — carrier callsigns look like `V4H-84Q`, which no starport does. The board re-checks
that you own the carrier regardless, so a wrong guess is a rejected upload rather than bad data.

## Settings

| Setting | Meaning |
| --- | --- |
| Send carrier events | Master switch. Nothing is sent without an API key either way |
| Board URL | Defaults to `https://grayflare.space/fc` |
| API key | From the board's settings page. Stored in EDMC's own config |

## Troubleshooting

**`bad API key`** — the key was revoked or mistyped. Generate a new one on the settings page.

**`already claimed by another account`** — someone else's account claimed that carrier first. The
current owner can release it from the carrier's Manage tab.

**Nothing happens** — carrier events only appear in the journal when you interact with the carrier.
Dock at it and open Carrier Management.

EDMC's log (**File → Settings → Configuration → Open Log Folder**) has the detail; the plugin logs
under `EDMarketConnector.CarrierOps`.

## Licence

BSD-3-Clause, copyright 2026 Carrier Ops. Contains no EDMarketConnector code; it uses EDMC's documented
plugin entry points. See `NOTICE.md` in the parent project.
