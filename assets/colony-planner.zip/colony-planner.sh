#!/usr/bin/env sh
# Start the planner from wherever this script happens to live, so it works from
# a menu entry, a symlink or a shell that is somewhere else entirely.
set -eu
cd "$(dirname "$0")"

for python in python3 python; do
    if command -v "$python" >/dev/null 2>&1; then
        exec "$python" colony_planner.py "$@"
    fi
done

echo "colony-planner: no python3 on PATH" >&2
exit 1
