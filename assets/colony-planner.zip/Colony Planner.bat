@echo off
rem Start without a console window hanging around behind the app. pythonw is
rem the windowed interpreter; if it is missing for any reason, python still
rem works and only costs a black rectangle.
setlocal
cd /d "%~dp0"
where pythonw >nul 2>&1 && (start "" pythonw "colony_planner.py" & exit /b)
python "colony_planner.py"
