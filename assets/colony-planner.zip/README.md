# Colony Planner

What a construction site still needs, and whether you are already carrying any of it.

**Windows:** double-click `Colony Planner.bat`.
**Linux:** `chmod +x colony-planner.sh` once, then run it.

Nothing to install on Windows. On Linux you need Tk, which most distributions package separately —
`python3-tk` on Debian and Ubuntu, `python3-tkinter` on Fedora, `tk` on Arch. The program says so
itself if it is missing, rather than showing you a traceback about `_tkinter`.

Beyond that it is standard library only.

## The problem it solves

The construction panel is readable in exactly one place: docked at the site. That is the one place
the answer has stopped being useful, because by then you have already chosen a load, flown out, and
filled the hold with something else.

The journal has all of it. Every time that panel updates, the game writes a
`ColonisationConstructionDepot` event carrying the whole manifest — every commodity, how much is
wanted, how much has arrived. This reads that and shows what is left.

## What you get

- **Every construction site** the journals have ever seen, unfinished ones first
- **Per commodity:** needed, delivered, and **to buy** — what is still short after what is in your
  hold and on your carrier, since neither of those has to be bought again
- **Rows you can deliver are highlighted**, so a glance says whether this trip is worth landing
- **Two totals, because they answer different questions:** what the site is short of decides how
  much flying is left, and what *you* are short of decides what to go and buy. Loads counts the
  first, at whatever cargo capacity you set — filled in from your last `Loadout`, so it is usually
  right without touching it
- **Copy list** puts the shopping list on the clipboard as name and tonnes, tab separated, which
  pastes straight into a spreadsheet. It lists what is left to buy, not what the site is short of —
  otherwise it would send you out for cargo already sitting on your own carrier
- **Follow the journal** keeps it current while you play, checking every four seconds
- **On carrier** shows what your fleet carrier is already holding, if you point it at a Carrier Ops
  board — see below
- **Sold here** shows what the station you are docked at has in stock, with those rows highlighted,
  so you can see at a glance whether this is a place worth loading up at

Click any column heading to sort by it. Names sort A–Z, quantities sort largest first, since the
large ones are what you are looking for.

## What the station sells

Open the commodities market once and the **Sold here** column fills in, highlighting every row the
station can supply. The summary says how much of the build is buyable there — capped at what is
actually still wanted, since a station holding a million tonnes of scrap is not offering a million
tonnes of progress.

The status line names the station, and it is named for a reason: `Market.json` is written when a
commodities screen is opened, not when a ship docks, so it can easily describe somewhere you left an
hour ago. If the journal says you are docked somewhere else, it says so rather than letting you plan
a run against the wrong market.

## Hauling with other people

Tick **Share this build** in the Carrier… box. From then on the planner posts what it can see of the
construction site every fifteen seconds and reads back what everybody else can — and a new column,
**Others have**, shows what the rest of the group is already carrying.

That column changes the arithmetic that matters. **To buy** subtracts it, so a commodity the group
has covered between them drops to `—` and stops appearing on your shopping list. Steel needing
72,845 t with 60,728 t already spread across two other carriers reads as 12,117 t to buy, not 72,845.

Under the progress bar is who else is on the build:

    2 of 3 hauling now  ·  ● Grayflare [K7G-52T]  ● ToxicTheTaidum [V4H-84Q]  ○ techno312

A filled dot means the board has heard from them in the last minute. There is no connection to be up
or down — each planner simply posts every fifteen seconds and stops when it is closed — so presence
is a question about timestamps, and a hollow dot means somebody has stopped reporting rather than
that anything is broken.

**The site's own figures are shared too.** Whoever docked there most recently supplies the manifest
for everyone, so Needed and Delivered move when somebody else delivers, not only when you fly there
yourself. The status line says *by the crew* when what you are looking at came from somebody else.

An older reading is refused rather than merged: readings arrive from several machines in whatever
order they are sent, and most-recent-wins is the only rule that survives that. Your planner still
reports only what it read itself — it never echoes the shared figures back as though they were its
own, or the newest reading would be laundered into every machine's and none of them would age.

Somebody who joined on an invitation and has not flown there yet sees the crew's manifest straight
away, and their hold is pooled from the first report — they do not have to dock once to become
useful.

### Inviting people

Nobody else needs an account. Press **Invite…** and a window opens with a token for this one build,
already copied to your clipboard — paste it into Discord. Whoever receives it puts it in the same **API key** box as an
account key would go, and they are on the build.

A token works on that construction site and nothing else. It cannot read a carrier, cannot upload a
journal, cannot look up any other build, and cannot even ask about one — it already knows which site
it belongs to. Anybody who has done a run on a build can invite others to it; there is no owner,
because a colonisation crew does not have one.

Only the hash is stored, so that window is the last time the token can be read. That is why it is a
window and not a line of text in the corner: miss it and the only remedy is to mint another and
wonder what became of the first.

## Your carrier's hold

Click **Carrier…** and give it a board address, an API key from that board's settings page, and a
callsign. The column fills in and the summary gains a line like *45,000 t already on V4H-84Q*.

It has to come from the board, because the journal does not have it. `CarrierStats` reports how many
tonnes are aboard and never what they are, and no other event carries a manifest — that only exists
in Frontier's Companion API, which is what the board holds.

That manifest is up to fifteen minutes old, so transfers and carrier-market trades from your journal
are added on top of it. Only ones newer than the manifest count, so nothing is counted twice, and
only ones at that carrier. Both halves matter: on these journals there were 270 buys from the
commander's own carrier against 260 transfers, because stocking the carrier and buying it back into
the ship is how a long haul actually runs, and a tracker watching only transfers would think 41,920 t
of steel was still aboard.

The key is kept in `%LOCALAPPDATA%\ColonyPlanner\config.json`, not beside this script — a project
folder is the sort of thing that gets zipped and sent to somebody.

Leave any of the three fields blank to switch the column off again.

## Running under Linux

Elite is a Windows program wherever it runs, so under Proton or Wine it still writes to `Saved Games`
— the only question is which fake C: drive that is inside. The prefix is found by looking rather than
by composing a path from a Steam app id: the id would need keeping current, it is different for a
Lutris or Bottles install, and the user inside the prefix is `steamuser` under Proton but your own
login name under plain Wine.

Steam libraries on other drives are read out of `libraryfolders.vdf`, so a game installed away from
your home directory is found too. If several prefixes contain journals — an old Proton version, a
second account — the one with the most recently written journal wins.

Set `JOURNAL_DIR` to override all of it.

Two Linux details worth knowing. The config lives at `$XDG_CONFIG_HOME/colony-planner/config.json`
(or `~/.config/...`), and is written `0600` because it holds an API key. And **Copy list** puts the
text on the X11 clipboard, which belongs to the program that owns it — paste it before you close the
window, or run a clipboard manager.

## Notes

The first scan reads every journal you have; on 272 files that took under two seconds. After that it
only reads what has been appended, which takes about forty milliseconds — so following along while
you play costs nothing.

A site appears only once you have docked at it at least once, because that is when the game first
writes the manifest. A site whose name shows as `Site 3959882242` was seen in a manifest but never in
a `Docked` event; dock there once and it gets its name.

If the game writes journals somewhere unusual, set `JOURNAL_DIR`. Otherwise the Saved Games location
is read from the registry rather than assumed, since that folder can be moved and OneDrive moves it
without asking.
