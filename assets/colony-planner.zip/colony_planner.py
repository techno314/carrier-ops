"""
Colony Planner -- what a construction site still needs, and whether you are
carrying any of it.

Colonisation is a hauling problem wearing a building's clothes. The game tells
you the totals on a panel you can only read while docked at the site, which is
the one place the answer is no longer useful: by then you have already chosen a
load, flown out, and filled the hold with something else.

The journal knows all of it. Every time the construction depot's panel updates,
the game writes a ColonisationConstructionDepot event carrying the full
manifest -- every commodity, how much is wanted, how much has arrived. This
reads that, subtracts one from the other, and puts what is left next to what is
in your hold right now.

Several people hauling to one site can share what they each see, through a
Carrier Ops board. Nobody's journal knows about anybody else's, so without that
two of them buy fifty thousand tonnes of steel for a site that wanted seventy
and neither finds out until the second one arrives.

Standard library only, deliberately. It has to run on a machine that has Python
and nothing else, and asking somebody to pip install a thing before they can
find out how much steel they need is a poor trade.
"""

from __future__ import annotations

import glob
import json
import math
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass, field

try:
    import tkinter as tk
    from tkinter import ttk
except ImportError:                                        # pragma: no cover
    # Tk ships with Python on Windows and macOS, and is a separate package on
    # most Linux distributions. A traceback about `_tkinter` tells somebody
    # nothing; the package name tells them everything.
    sys.stderr.write(
        "Colony Planner needs Tk, which is packaged separately on Linux.\n"
        "  Debian, Ubuntu, Mint:  sudo apt install python3-tk\n"
        "  Fedora:                sudo dnf install python3-tkinter\n"
        "  Arch:                  sudo pacman -S tk\n"
    )
    raise SystemExit(1)

APP_NAME = "Colony Planner"
VERSION = "1.1.0"

# Only these are worth parsing. Every other line in a journal is skipped on a
# substring test before json.loads is ever called, which is the difference
# between a scan that takes a moment and one that takes a minute: a commander
# with a few years of play has hundreds of megabytes of journals, and almost
# none of it is about building anything.
WANTED = (
    '"event":"ColonisationConstructionDepot"',
    '"event":"ColonisationContribution"',
    '"event":"Docked"',
    '"event":"Location"',
    '"event":"Undocked"',
    '"event":"Loadout"',
    '"event":"LoadGame"',
    # Everything that moves cargo on or off a fleet carrier. Transfers are the
    # obvious half; the market is the half people forget, and on this commander's
    # journals it is the larger one -- 270 buys from their own carrier against
    # 260 transfers, because stocking the carrier and then buying it back into
    # the ship is how a long haul is actually run.
    '"event":"CargoTransfer"',
    '"event":"MarketBuy"',
    '"event":"MarketSell"',
)

REFRESH_MS = 2000

# The board is asked far less often than the journal is read. Its answer comes
# from Frontier's Companion API, which is itself only refreshed every fifteen
# minutes, so polling it faster would produce the same bytes and spend somebody
# else's rate limit doing it.
CARRIER_REFRESH_MS = 120_000

# The shared build is asked far more often, because it is not Frontier's data
# and not cached anywhere -- it is a handful of rows on a board we run, and the
# whole point of it is that four people hauling at once see each other move.
#
# Two seconds. A crew standing at the same market deciding who buys what needs
# to see each other inside the time it takes to say it, and a report is a few
# hundred bytes against a database on the other end of a LAN-speed connection.
# Four haulers is two requests a second, which that board would not notice.
COLONY_REFRESH_MS = 2000

# Where a Carrier Ops board lives unless told otherwise. Filled into the
# settings box rather than shown as a hint beneath it: a greyed-out example
# under an empty field reads as a value that is already there, and saving the
# form then stores a blank address that quietly disables the whole feature.
DEFAULT_BOARD = "https://grayflare.space/fc"

# A key beginning like this is an invitation to one construction site rather
# than an account on the board. It works for the shared build and for nothing
# else, which is the point: somebody hauling for a fortnight should not have to
# register anywhere to help.
BUILD_TOKEN_PREFIX = "fcb_"


def is_build_token(key: str) -> bool:
    return str(key or "").strip().startswith(BUILD_TOKEN_PREFIX)


# How often to ask the board whether a newer planner exists. Rarely: a release
# is a thing that happens some days and not others, and the answer is checked
# again every time the program starts anyway.
UPDATE_CHECK_MS = 30 * 60 * 1000


def version_parts(version: str) -> list[int]:
    """
    Compare versions as numbers, component by component.

    As text, "1.10.0" sorts before "1.9.0" -- so an update would stop being
    offered at exactly the point the numbers got interesting.
    """
    return [int(n) for n in re.findall(r"\d+", version or "0")] or [0]


def is_newer(candidate: str, current: str) -> bool:
    a, b = version_parts(candidate), version_parts(current)
    for i in range(max(len(a), len(b))):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        if x != y:
            return x > y
    return False


def install_root() -> str:
    """The folder this program lives in, which is what an update replaces."""
    return os.path.dirname(os.path.abspath(__file__))


# --------------------------------------------------------------------- paths

FRONTIER = os.path.join("Frontier Developments", "Elite Dangerous")


def _windows_saved_games() -> list[str]:
    """
    Saved Games as Explorer records it, then the usual place.

    It has no %ENVVAR% form and does not live under Documents, and it can be
    moved -- OneDrive does it without asking -- so the folder id is asked first
    and the default is only a fallback.
    """
    roots = []
    try:
        import winreg

        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",
        ) as key:
            saved, _ = winreg.QueryValueEx(key, "{4C5C32FF-BB9D-43b0-B5B4-2D72E54EAAA4}")
        if saved:
            roots.append(str(saved))
    except Exception:
        pass

    roots.append(os.path.join(os.path.expanduser("~"), "Saved Games"))
    return roots


def _steam_libraries() -> list[str]:
    """
    Every Steam library on the machine, not just the one in the home directory.

    Games are routinely installed to a second drive, and the prefix follows the
    game. Steam records the extra libraries in libraryfolders.vdf; it is not
    JSON and does not deserve a parser, so the paths are simply picked out.
    """
    home = os.path.expanduser("~")
    roots = [
        os.path.join(home, ".steam", "steam"),
        os.path.join(home, ".local", "share", "Steam"),
        # Flatpak keeps its own home.
        os.path.join(home, ".var", "app", "com.valvesoftware.Steam", ".local", "share", "Steam"),
    ]

    found = list(roots)
    for root in roots:
        manifest = os.path.join(root, "steamapps", "libraryfolders.vdf")
        try:
            with open(manifest, "r", encoding="utf-8", errors="replace") as handle:
                text = handle.read()
        except OSError:
            continue
        for path in re.findall(r'"path"\s+"([^"]+)"', text):
            path = path.replace("\\\\", "/")
            if path not in found:
                found.append(path)
    return found


def _wine_journal_dirs() -> list[str]:
    """
    Elite's journals inside a Wine or Proton prefix.

    The game is a Windows program wherever it runs, so it still writes to
    `Saved Games` -- the question is only which fake C: drive that is inside.

    Globbed rather than composed from a Steam app id. The id would have to be
    kept current, it is different for a Lutris or Bottles install, and the user
    inside the prefix is `steamuser` under Proton and the real login name under
    plain Wine. Asking the filesystem sidesteps all three.
    """
    home = os.path.expanduser("~")
    patterns = []

    for library in _steam_libraries():
        patterns.append(os.path.join(
            library, "steamapps", "compatdata", "*", "pfx", "drive_c", "users", "*", "Saved Games"))

    patterns += [
        os.path.join(home, ".wine", "drive_c", "users", "*", "Saved Games"),
        os.path.join(home, "Games", "*", "drive_c", "users", "*", "Saved Games"),
        os.path.join(home, ".local", "share", "wineprefixes", "*", "drive_c", "users", "*", "Saved Games"),
        # Bottles, and Lutris under Flatpak.
        os.path.join(home, ".var", "app", "com.usebottles.bottles", "data", "bottles",
                     "bottles", "*", "drive_c", "users", "*", "Saved Games"),
        os.path.join(home, ".var", "app", "net.lutris.Lutris", "data", "lutris",
                     "runners", "winesteam", "*", "drive_c", "users", "*", "Saved Games"),
    ]

    # Deduplicated on the resolved path: libraryfolders.vdf names the default
    # library as well as the extra ones, and ~/.steam/steam is usually a symlink
    # to ~/.local/share/Steam, so the same prefix arrives by three routes.
    hits: list[str] = []
    seen: set[str] = set()
    for pattern in patterns:
        for saved in glob.glob(pattern):
            candidate = os.path.join(saved, FRONTIER)
            if not os.path.isdir(candidate):
                continue
            key = os.path.realpath(candidate)
            if key in seen:
                continue
            seen.add(key)
            hits.append(candidate)
    return hits


def journal_dir() -> str:
    """
    Where the game writes its journals.

    JOURNAL_DIR wins outright, on every platform -- for an install none of the
    guesses below cover, or for journals copied from another machine.

    Otherwise: on Windows, Saved Games. Anywhere else, the game is running under
    Wine or Proton, so its Saved Games is inside a prefix and has to be found.
    A plain `~/Saved Games` is checked too, since that is where somebody who
    copied journals across would naturally put them.
    """
    override = os.environ.get("JOURNAL_DIR")
    if override and os.path.isdir(override):
        return override

    candidates: list[str] = []

    if sys.platform == "win32":
        candidates += [os.path.join(root, FRONTIER) for root in _windows_saved_games()]
    else:
        candidates += _wine_journal_dirs()
        candidates.append(os.path.join(os.path.expanduser("~"), "Saved Games", FRONTIER))

    existing = [c for c in candidates if os.path.isdir(c)]
    if not existing:
        # Nothing found. Return the most likely name anyway so the window can
        # say which folder it looked for rather than nothing at all.
        return candidates[-1] if candidates else os.path.join(
            os.path.expanduser("~"), "Saved Games", FRONTIER)

    # Several prefixes can hold journals -- an old Proton version, a second
    # account, a Lutris install left over from before Steam. The one being
    # written to is the one that matters.
    return max(existing, key=_newest_journal_time)


def _newest_journal_time(directory: str) -> float:
    try:
        stamps = [
            os.path.getmtime(os.path.join(directory, name))
            for name in os.listdir(directory)
            if name.startswith("Journal.") and name.endswith(".log")
        ]
    except OSError:
        return 0.0
    return max(stamps, default=0.0)


def commodity_name(entry: dict) -> str:
    """
    A readable name.

    Name_Localised is there most of the time; when it is not, the symbol is
    `$steel_name;` and has to be unwrapped. Both forms turn up in the same
    manifest, so neither can be assumed.
    """
    localised = entry.get("Name_Localised")
    if isinstance(localised, str) and localised.strip():
        return localised.strip()

    raw = str(entry.get("Name", "")).strip()
    if raw.startswith("$"):
        raw = raw[1:]
    for suffix in ("_name;", "_name", ";"):
        if raw.lower().endswith(suffix):
            raw = raw[: -len(suffix)]
            break
    return raw.replace("_", " ").title() or "?"


def commodity_key(entry: dict) -> str:
    """
    The internal symbol, which is what the board and everyone else key on.

    Display names are for reading and are localised; `steel` is the same in
    every client. Both are sent when a build is reported, so one machine's
    German journal and another's English one still describe the same commodity.
    """
    raw = str(entry.get("Name") or entry.get("Type") or entry.get("commodity") or "").strip()
    raw = raw.lstrip("$")
    for suffix in ("_name;", "_name", ";"):
        if raw.lower().endswith(suffix):
            raw = raw[: -len(suffix)]
            break
    return raw.lower()


def pretty_station(name: str) -> str:
    """
    A construction site's name, with the machinery taken off the front.

    Two shapes turn up, and both bury the only part worth reading:

        Orbital Construction Site: Brongniart Vision
        $EXT_PANEL_ColonisationShip; Cunha Gateway

    The first is merely long -- every one of them starts that way, so the
    prefix says nothing. The second is a localisation token the game did not
    resolve, and unlike commodities there is no StationName_Localised beside it
    to fall back on. Frontier writes the real name after the token, so the
    token is dropped and what follows is kept.
    """
    trimmed = name.strip()

    if trimmed.startswith("$"):
        _, sep, rest = trimmed.partition(";")
        if sep and rest.strip():
            trimmed = rest.strip()
        else:
            # Nothing after the token: show it without the punctuation rather
            # than a bare `$`, which reads as a fault in this program.
            trimmed = trimmed.lstrip("$").rstrip(";").replace("_", " ").strip()

    if ":" in trimmed:
        trimmed = trimmed.split(":", 1)[1].strip() or trimmed

    return trimmed or name


# -------------------------------------------------------------------- config

def config_path() -> str:
    """
    Beside the user's other application data, not beside this script.

    The file holds an API key, and a project folder is the sort of thing that
    gets zipped and sent to somebody. %LOCALAPPDATA% and ~/.config are not.
    """
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "ColonyPlanner", "config.json")

    # XDG on everything else, honouring the variable rather than assuming the
    # default -- somebody who has moved their config directory meant it.
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "colony-planner", "config.json")


def load_config() -> dict:
    try:
        with open(config_path(), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_config(config: dict) -> bool:
    path = config_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(config, handle, indent=2)
        if sys.platform != "win32":
            # It holds an API key, and a home directory is not private on a
            # shared machine. Windows inherits usable ACLs from LOCALAPPDATA;
            # a POSIX file is whatever the umask happened to be.
            os.chmod(path, 0o600)
        return True
    except OSError:
        return False


def journal_time(stamp: str) -> str:
    """
    A board timestamp in the journal's own format, so the two can be compared.

    The board says `2026-08-06 22:00:05`; the journal says
    `2026-08-06T22:00:05Z`. Both are UTC and both sort correctly as text, but
    only once they agree on the punctuation between them.
    """
    stamp = (stamp or "").strip()
    if not stamp:
        return ""
    if " " in stamp and "T" not in stamp:
        stamp = stamp.replace(" ", "T")
    return stamp if stamp.endswith("Z") else stamp + "Z"


# ---------------------------------------------------------------------- data

@dataclass
class Depot:
    market_id: int
    progress: float = 0.0
    complete: bool = False
    failed: bool = False
    timestamp: str = ""
    resources: list[dict] = field(default_factory=list)

    station: str | None = None
    system: str | None = None

    @property
    def label(self) -> str:
        if self.station is None:
            return f"Site {self.market_id}"
        name = pretty_station(self.station)
        return f"{name} — {self.system}" if self.system else name

    @property
    def remaining_total(self) -> int:
        return sum(self.remaining(r) for r in self.resources)

    @staticmethod
    def remaining(resource: dict) -> int:
        return max(0, int(resource.get("RequiredAmount", 0)) - int(resource.get("ProvidedAmount", 0)))

    @property
    def outstanding(self) -> list[dict]:
        return [r for r in self.resources if Depot.remaining(r) > 0]


@dataclass
class Market:
    """
    The commodity market of wherever the game last opened one.

    Market.json is rewritten when the commodities screen is opened, not when a
    ship docks -- so it can easily describe a station you left an hour ago. It
    names the station it came from, and so does this: guessing that it is where
    you are standing is how somebody flies to the wrong system.
    """
    market_id: int
    station: str
    system: str
    timestamp: str
    stock: dict[str, tuple[int, int]] = field(default_factory=dict)   # name -> (stock, buy price)

    def has(self, commodity: str) -> int:
        return self.stock.get(commodity, (0, 0))[0]

    def price(self, commodity: str) -> int:
        return self.stock.get(commodity, (0, 0))[1]


class Journals:
    """
    The journal folder, read once and then only where it has grown.

    Re-reading everything on a timer would be wasteful and, on a live journal,
    increasingly slow as the session goes on. So each file's consumed length is
    remembered and only the tail is parsed next time. A file that has shrunk has
    been replaced rather than appended to, and is read again from the start.
    """

    def __init__(self, directory: str) -> None:
        self.directory = directory
        self.offsets: dict[str, int] = {}

        self.depots: dict[int, Depot] = {}
        self.markets: dict[int, tuple[str | None, str | None]] = {}
        self.cargo_capacity: int | None = None
        self.ship: str | None = None
        self.cmdr: str | None = None
        # What this commander has personally handed over, per site. The site's
        # own `provided` figure counts everybody's; this is the part that is
        # ours, which is what the group view wants to attribute.
        self.delivered: dict[int, dict[str, int]] = {}

        # Every movement of cargo on or off a carrier, as
        # (timestamp, carrier market id, commodity, tonnes signed toward the
        # carrier). Kept in full rather than summed, because which of them count
        # depends on how old the board's manifest is, and that changes.
        self.carrier_moves: list[tuple[str, int, str, int]] = []

        # Which carrier we are standing in, as the scan walks forward. A
        # CargoTransfer names no carrier -- it is written in the ship's journal
        # and says only what moved and which way -- so the docking that preceded
        # it is the only thing that says where the cargo went.
        self._docked_carrier: int | None = None

        # Where we are docked at all, carrier or not. Only used to tell whether
        # Market.json describes here or somewhere already left behind.
        self.docked_at: int | None = None

        self._market: Market | None = None
        # Display name -> symbol, filled in as manifests are read. The hold
        # and the carrier are keyed by display name; the board wants symbols.
        self._market_at: float = -1.0

    def files(self) -> list[str]:
        try:
            names = [
                n for n in os.listdir(self.directory)
                if n.startswith("Journal.") and n.endswith(".log")
            ]
        except OSError:
            return []
        names.sort(key=lambda n: os.path.getmtime(os.path.join(self.directory, n)))
        return [os.path.join(self.directory, n) for n in names]

    def scan(self) -> None:
        for path in self.files():
            try:
                size = os.path.getsize(path)
            except OSError:
                continue

            start = self.offsets.get(path, 0)
            if size < start:          # replaced, not appended to
                start = 0
            if size == start:
                continue

            try:
                with open(path, "r", encoding="utf-8", errors="replace") as handle:
                    handle.seek(start)
                    for line in handle:
                        self._apply(line)
                    self.offsets[path] = handle.tell()
            except OSError:
                continue

        # The station a depot belongs to is learned from a Docked event, which
        # may be read after the depot itself -- so names are attached at the end
        # rather than as each event arrives.
        for depot in self.depots.values():
            if depot.market_id in self.markets:
                depot.station, depot.system = self.markets[depot.market_id]

    def _apply(self, line: str) -> None:
        if not any(marker in line for marker in WANTED):
            return
        try:
            entry = json.loads(line)
        except ValueError:
            return

        event = entry.get("event")

        if event in ("Docked", "Location"):
            market_id = entry.get("MarketID")
            if isinstance(market_id, int):
                self.markets[market_id] = (entry.get("StationName"), entry.get("StarSystem"))
            self._docked_carrier = (
                market_id
                if entry.get("StationType") == "FleetCarrier" and isinstance(market_id, int)
                else None
            )
            # Location fires in flight as well as docked, and then says so.
            self.docked_at = (
                market_id
                if isinstance(market_id, int) and entry.get("Docked", True)
                else None
            )
            return

        if event == "Undocked":
            self._docked_carrier = None
            self.docked_at = None
            return

        if event == "CargoTransfer":
            if self._docked_carrier is None:
                return
            stamp = str(entry.get("timestamp", ""))
            for move in entry.get("Transfers", []) or []:
                if not isinstance(move, dict):
                    continue
                count = int(move.get("Count", 0) or 0)
                direction = str(move.get("Direction", "")).lower()
                if count <= 0 or direction not in ("tocarrier", "toship"):
                    continue
                self.carrier_moves.append((
                    stamp,
                    self._docked_carrier,
                    commodity_name({"Name": move.get("Type"), "Name_Localised": move.get("Type_Localised")}),
                    count if direction == "tocarrier" else -count,
                ))
            return

        if event in ("MarketBuy", "MarketSell"):
            # Only trades at a carrier move a carrier's stock, and a buy takes
            # it away: the commodity leaves the hold and arrives in the ship.
            market_id = entry.get("MarketID")
            if not isinstance(market_id, int):
                return
            count = int(entry.get("Count", 0) or 0)
            if count <= 0:
                return
            self.carrier_moves.append((
                str(entry.get("timestamp", "")),
                market_id,
                commodity_name({"Name": entry.get("Type"), "Name_Localised": entry.get("Type_Localised")}),
                -count if event == "MarketBuy" else count,
            ))
            return

        if event == "LoadGame":
            # The only event that names the commander in the ordinary run of a
            # session. Read in file order, so the last one seen is whoever is
            # playing now -- which is what matters on a machine with several
            # accounts on it.
            cmdr = entry.get("Commander")
            if isinstance(cmdr, str) and cmdr.strip():
                self.cmdr = cmdr.strip()
            ship = entry.get("ShipName") or entry.get("Ship_Localised") or entry.get("Ship")
            if isinstance(ship, str) and ship.strip():
                self.ship = ship.strip()
            return

        if event == "Loadout":
            capacity = entry.get("CargoCapacity")
            if isinstance(capacity, int):
                self.cargo_capacity = capacity
            ship = entry.get("ShipName") or entry.get("Ship")
            if isinstance(ship, str) and ship.strip():
                self.ship = ship.strip()
            return

        if event == "ColonisationContribution":
            market_id = entry.get("MarketID")
            if not isinstance(market_id, int):
                return
            into = self.delivered.setdefault(market_id, {})
            for item in entry.get("Contributions", []) or []:
                if not isinstance(item, dict):
                    continue
                key = commodity_key(item)
                amount = int(item.get("Amount", 0) or 0)
                if key and amount > 0:
                    into[key] = into.get(key, 0) + amount
            return

        if event == "ColonisationConstructionDepot":
            market_id = entry.get("MarketID")
            if not isinstance(market_id, int):
                return
            # Latest wins outright. These events are snapshots of the whole
            # manifest, not deltas, so the newest one is the complete truth and
            # merging with an older one could only make it wrong.
            self.depots[market_id] = Depot(
                market_id=market_id,
                progress=float(entry.get("ConstructionProgress", 0.0) or 0.0),
                complete=bool(entry.get("ConstructionComplete", False)),
                failed=bool(entry.get("ConstructionFailed", False)),
                timestamp=str(entry.get("timestamp", "")),
                resources=[r for r in entry.get("ResourcesRequired", []) if isinstance(r, dict)],
            )

    def cargo(self) -> dict[str, int]:
        """
        What is in the hold right now, keyed the way the manifest is.

        Cargo.json rather than the journal's Cargo event: the event says only
        how many items there are when the inventory is long, and the file is
        rewritten every time the hold changes anyway.
        """
        path = os.path.join(self.directory, "Cargo.json")
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return {}

        held: dict[str, int] = {}
        for item in data.get("Inventory", []) or []:
            if not isinstance(item, dict):
                continue
            held[commodity_name(item)] = held.get(commodity_name(item), 0) + int(item.get("Count", 0))
        return held

    def market(self) -> Market | None:
        """
        The last commodity market the game wrote out.

        Cached on the file's timestamp. It is a hundred kilobytes of JSON and
        the window redraws every four seconds, so re-reading it each time would
        be the most expensive thing this program does, for an answer that only
        changes when a market screen is opened.
        """
        path = os.path.join(self.directory, "Market.json")
        try:
            stamp = os.path.getmtime(path)
        except OSError:
            return None

        if self._market is not None and stamp == self._market_at:
            return self._market

        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return self._market

        stock: dict[str, tuple[int, int]] = {}
        for item in data.get("Items") or []:
            if not isinstance(item, dict):
                continue
            # Only what can actually be bought. A market lists every commodity
            # it has an opinion about, and 321 of this station's 353 entries are
            # things it wants to buy from you rather than sell.
            count = int(item.get("Stock", 0) or 0)
            if count <= 0:
                continue
            stock[commodity_name(item)] = (count, int(item.get("BuyPrice", 0) or 0))

        self._market = Market(
            market_id=int(data.get("MarketID", 0) or 0),
            station=str(data.get("StationName") or "?"),
            system=str(data.get("StarSystem") or "?"),
            timestamp=str(data.get("timestamp") or ""),
            stock=stock,
        )
        self._market_at = stamp
        return self._market

    def moves_since(self, market_id: int, since: str) -> dict[str, int]:
        """
        What has moved on or off this carrier since the board last looked.

        `since` is the board's own cargoAt, so nothing already counted in its
        manifest is counted again. Journal timestamps are UTC and sort as text,
        which is the whole reason this comparison can be a string one.
        """
        moved: dict[str, int] = {}
        for stamp, mid, name, delta in self.carrier_moves:
            if mid != market_id or stamp <= since:
                continue
            moved[name] = moved.get(name, 0) + delta
        return moved


class CarrierLink:
    """
    The carrier's hold, from the Carrier Ops board with journal events on top.

    The board is the only thing that knows what is actually aboard: it holds a
    manifest Frontier gave it, and no amount of journal reading can produce one
    -- CarrierStats reports a tonnage and never a breakdown. But that manifest
    is up to fifteen minutes old and says nothing about the load you shifted two
    minutes ago, which is exactly the load you are standing there wondering
    about.

    So the board supplies the baseline and the journal supplies what has
    happened since. It is the same arrangement the board itself uses against
    Frontier, for the same reason.

    Fetched on a worker thread. A board that is slow, or down, must not freeze
    a window whose whole job is to be glanceable.
    """

    def __init__(self) -> None:
        self.manifest: dict[str, int] = {}
        self.market_id: int | None = None
        self.cargo_at: str = ""
        self.callsign: str | None = None
        self.error: str | None = None
        self.fetched_at: float = 0.0
        self._busy = False

    def configured(self, config: dict) -> bool:
        # The address is the one field with a sensible default, so its absence
        # is not a reason to do nothing. A build token is a different matter:
        # it cannot read a carrier at all, and asking anyway would produce an
        # error message about a feature the holder never asked for.
        return bool(
            config.get("api_key")
            and config.get("carrier")
            and not is_build_token(config.get("api_key", ""))
        )

    def fetch_async(self, config: dict, done) -> None:
        if self._busy or not self.configured(config):
            return
        self._busy = True

        def work() -> None:
            try:
                self._fetch(config)
            finally:
                self._busy = False
                done()

        threading.Thread(target=work, name="carrier fetch", daemon=True).start()

    def _fetch(self, config: dict) -> None:
        # Everything from here down runs on a worker thread, where an escaping
        # exception is invisible: there is no console under pythonw, and the
        # window would simply go on showing an empty column for ever. So the
        # request is built inside the guard too, not just sent inside it.
        try:
            base = (config.get("board_url") or DEFAULT_BOARD).strip().rstrip("/")
            if "://" not in base:
                base = "https://" + base
            url = base + "/api.php?action=carrier&id=" + urllib.parse.quote(str(config["carrier"]))
            request = urllib.request.Request(url, headers={
                "X-API-Key": config["api_key"],
                "Accept": "application/json",
                "User-Agent": f"ColonyPlanner/{VERSION}",
            })
            with urllib.request.urlopen(request, timeout=15) as response:
                data = json.load(response)
        except urllib.error.HTTPError as err:
            self.error = f"board returned {err.code}"
            return
        except (urllib.error.URLError, OSError, ValueError) as err:
            self.error = f"could not reach the board: {err}"
            return
        except Exception as err:                          # noqa: BLE001
            self.error = f"carrier lookup failed: {err}"
            return

        if not isinstance(data, dict) or "error" in data:
            self.error = str((data or {}).get("error", "unexpected reply"))
            return

        rows = data.get("cargo")
        if rows is None:
            # The board answered, and withheld the hold. Both causes look
            # identical from here: the endpoint serves public carrier data to
            # anyone, so a wrong key is not rejected, it is merely not
            # recognised as the owner. Naming one cause would send somebody
            # looking in the wrong place.
            self.error = "no hold returned — check the key is right and owns this carrier"
            return

        manifest: dict[str, int] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            name = row.get("name") or commodity_name({"Name": row.get("commodity")})
            manifest[name] = manifest.get(name, 0) + int(row.get("quantity", 0) or 0)

        self.manifest = manifest
        self.cargo_at = journal_time(str(data.get("cargoAt") or ""))
        self.callsign = data.get("callsign")
        try:
            self.market_id = int(data.get("id"))
        except (TypeError, ValueError):
            self.market_id = None
        self.error = None
        self.fetched_at = time.time()

    def hold(self, journals: Journals) -> dict[str, int]:
        """The manifest, brought forward to now."""
        if not self.manifest and self.market_id is None:
            return {}
        combined = dict(self.manifest)
        if self.market_id is not None and self.cargo_at:
            for name, delta in journals.moves_since(self.market_id, self.cargo_at).items():
                combined[name] = combined.get(name, 0) + delta
        return {name: qty for name, qty in combined.items() if qty > 0}


# ------------------------------------------------------------------------ ui

class ColonyLink:
    """
    The build as everybody hauling to it can see it.

    One call does both halves: this machine posts what it can see and the board
    answers with the sum. That keeps it to a single request every fifteen
    seconds per hauler, and means a planner can never be showing a merged view
    that does not already include its own contribution to it.

    What is posted is only ever this commander's own position -- their manifest
    reading, their hold, their carrier, their deliveries. Nobody's report can
    contradict anybody else's, so there is no merge to argue about: the newest
    manifest wins and the stock lists simply add up.
    """

    # A hauler counts as present if the board heard from them this recently.
    # Several missed reports rather than one, so a slow request or a moment of
    # packet loss does not make somebody blink out of the list. The board can
    # say otherwise; this is only what to think before it has.
    PRESENT_SECONDS = 60

    def __init__(self) -> None:
        # What the board says the intervals should be. Empty until the first
        # reply, so the constants above are what a first run uses.
        self.settings: dict[str, int] = {}
        self.site: dict = {}
        self.needs: list[dict] = []
        self.haulers: list[dict] = []
        self.error: str | None = None
        self.market_id: int | None = None
        self.fetched_at: float = 0.0
        self._busy = False

    def configured(self, config: dict) -> bool:
        return bool(config.get("api_key") and config.get("share"))

    def sync_async(self, config: dict, report: dict, done) -> None:
        if self._busy or not self.configured(config):
            return
        self._busy = True

        def work() -> None:
            try:
                self._sync(config, report)
            finally:
                self._busy = False
                done()

        threading.Thread(target=work, name="colony sync", daemon=True).start()

    def _sync(self, config: dict, report: dict) -> None:
        try:
            base = (config.get("board_url") or DEFAULT_BOARD).strip().rstrip("/")
            if "://" not in base:
                base = "https://" + base
            request = urllib.request.Request(
                base + "/api.php?action=colony_report",
                data=json.dumps(report).encode("utf-8"),
                method="POST",
                headers={
                    "X-API-Key": config["api_key"],
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": f"ColonyPlanner/{VERSION}",
                },
            )
            with urllib.request.urlopen(request, timeout=15) as response:
                data = json.load(response)
        except urllib.error.HTTPError as err:
            self.error = f"board returned {err.code}"
            return
        except (urllib.error.URLError, OSError, ValueError) as err:
            self.error = f"could not reach the board: {err}"
            return
        except Exception as err:                          # noqa: BLE001
            self.error = f"share failed: {err}"
            return

        if not isinstance(data, dict) or "error" in data:
            self.error = str((data or {}).get("error", "unexpected reply"))
            return

        got = data.get("settings")
        if isinstance(got, dict):
            self.settings = {k: int(v) for k, v in got.items() if isinstance(v, (int, float))}
        self.site = data.get("site") or {}
        self.needs = [n for n in (data.get("needs") or []) if isinstance(n, dict)]
        self.haulers = [h for h in (data.get("haulers") or []) if isinstance(h, dict)]
        self.error = None
        self.fetched_at = time.time()
        try:
            self.market_id = int(self.site.get("marketId"))
        except (TypeError, ValueError):
            self.market_id = None

    def by_commodity(self) -> dict[str, dict]:
        """The merged rows, keyed by symbol so a local row can find its match."""
        return {str(n.get("commodity", "")).lower(): n for n in self.needs}

    def present(self) -> list[tuple[str, bool, str | None]]:
        """
        Who is on this build, and which of them are reporting right now.

        Presence is simply how recently the board heard from them. There is no
        connection to be up or down -- a planner posts every fifteen seconds and
        stops when it is closed -- so "currently connected" is a question about
        timestamps rather than sockets.
        """
        now = time.time()
        out = []
        for hauler in self.haulers:
            stamp = journal_time(str(hauler.get("updatedAt") or ""))
            age = _age_seconds(stamp, now)
            out.append((
                str(hauler.get("cmdr") or "someone"),
                age is not None and age <= self.settings.get("presentSeconds", self.PRESENT_SECONDS),
                hauler.get("carrier"),
            ))
        # Present first, then alphabetical, so the list does not reshuffle every
        # time somebody's report lands.
        out.sort(key=lambda item: (not item[1], item[0].lower()))
        return out


def _age_seconds(stamp: str, now: float) -> float | None:
    """Seconds since a `YYYY-MM-DDTHH:MM:SSZ` stamp, without a date parser."""
    try:
        parts = [int(x) for x in re.findall(r"\d+", stamp)[:6]]
        if len(parts) < 6:
            return None
        import calendar
        return now - calendar.timegm(tuple(parts) + (0, 0, 0))
    except (ValueError, TypeError):
        return None


class SelfUpdate:
    """
    Is a newer planner out, and can this copy replace itself with it?

    It asks the board rather than a code host, because the board is the machine
    this program already talks to and the one place a crew is guaranteed to
    reach. A hauler who joined on an invitation has no account anywhere else and
    should not need one to stay current.

    Replacing a running Python program is safe in a way that replacing a running
    executable is not: the interpreter reads each source file once, at import,
    and never holds it open afterwards. So the files can be overwritten
    underneath a live process, and the change takes effect when it next starts.
    """

    def __init__(self) -> None:
        self.latest: str | None = None
        self.url: str | None = None
        self.notes: str | None = None
        self.error: str | None = None
        self.busy = False

    def available(self) -> bool:
        return self.latest is not None and is_newer(self.latest, VERSION)

    def check_async(self, config: dict, done) -> None:
        if self.busy:
            return
        self.busy = True

        def work() -> None:
            try:
                self._check(config)
            finally:
                self.busy = False
                done()

        threading.Thread(target=work, name="planner update check", daemon=True).start()

    def _check(self, config: dict) -> None:
        try:
            base = (config.get("board_url") or DEFAULT_BOARD).strip().rstrip("/")
            if "://" not in base:
                base = "https://" + base
            request = urllib.request.Request(
                base + "/api.php?action=planner",
                headers={"Accept": "application/json", "User-Agent": f"ColonyPlanner/{VERSION}"},
            )
            with urllib.request.urlopen(request, timeout=15) as response:
                data = json.load(response)
        except Exception as err:                          # noqa: BLE001
            # Offline, or a board that does not offer the planner. Neither is
            # worth reporting to somebody who did not ask.
            self.error = str(err)
            return

        if not isinstance(data, dict) or not data.get("version"):
            self.error = "the board did not say which version it has"
            return

        self.latest = str(data["version"])
        self.url = str(data.get("url") or "")
        self.notes = data.get("notes")
        self.error = None

    def apply(self, config: dict) -> tuple[bool, str]:
        """
        Download the new planner and write it over this one.

        Extracted to a temporary folder first and only copied across once every
        file has arrived. A half-downloaded zip that overwrote the program in
        place would leave something that neither runs nor updates.
        """
        if not self.url:
            return False, "no download was offered"

        base = (config.get("board_url") or DEFAULT_BOARD).strip().rstrip("/")
        if "://" not in base:
            base = "https://" + base
        url = self.url if "://" in self.url else base + "/" + self.url.lstrip("/")

        root = install_root()
        try:
            with tempfile.TemporaryDirectory(prefix="colony-planner-") as work:
                archive = os.path.join(work, "planner.zip")
                request = urllib.request.Request(
                    url, headers={"User-Agent": f"ColonyPlanner/{VERSION}"})
                with urllib.request.urlopen(request, timeout=120) as response, \
                        open(archive, "wb") as handle:
                    shutil.copyfileobj(response, handle)

                staged = os.path.join(work, "staged")
                os.makedirs(staged, exist_ok=True)
                with zipfile.ZipFile(archive) as zf:
                    for member in zf.infolist():
                        # Normalise separators and refuse anything that climbs
                        # out of the folder. A zip is somebody else's data even
                        # when the somebody is us.
                        name = member.filename.replace("\\", "/")
                        if name.endswith("/"):
                            continue
                        target = os.path.normpath(os.path.join(staged, name))
                        if not target.startswith(os.path.normpath(staged) + os.sep):
                            return False, f"the archive tried to write outside itself: {name}"
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with zf.open(member) as src, open(target, "wb") as dst:
                            shutil.copyfileobj(src, dst)

                written = 0
                for folder, _, files in os.walk(staged):
                    for name in files:
                        src = os.path.join(folder, name)
                        rel = os.path.relpath(src, staged)
                        dst = os.path.join(root, rel)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        shutil.copyfile(src, dst)
                        written += 1

            if written == 0:
                return False, "the archive was empty"
            return True, f"updated to {self.latest} — restart to finish"
        except Exception as err:                          # noqa: BLE001
            return False, f"update failed: {err}"

    def relaunch(self) -> None:
        """
        Start the new copy and stand down.

        Deliberately a fresh process rather than trying to reload in place:
        Python has already imported this file, and nothing short of starting
        again gives the new code a clean run.
        """
        script = os.path.join(install_root(), os.path.basename(__file__))
        creation = 0
        if sys.platform == "win32":
            creation = getattr(subprocess, "DETACHED_PROCESS", 0)
        subprocess.Popen([sys.executable, script], cwd=install_root(),
                         creationflags=creation, close_fds=True)


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {VERSION}")
        self.geometry("980x660")
        self.minsize(760, 460)

        self.journals = Journals(journal_dir())
        self.config = load_config()
        self.carrier = CarrierLink()
        self.colony = ColonyLink()
        self.updater = SelfUpdate()
        self.depot_ids: list[int] = []
        self.sort_column = "remaining"
        self.sort_reverse = True
        self.auto = tk.BooleanVar(value=True)
        self.hide_done = tk.BooleanVar(value=True)
        self.capacity = tk.StringVar(value="")
        self._held: dict[str, int] = {}
        self._aboard: dict[str, int] = {}
        self._market: Market | None = None
        # Display name -> symbol, filled in as manifests are read. The hold
        # and the carrier are keyed by display name; the board wants symbols.
        self._symbol_for: dict[str, str] = {}
        self._others: dict[str, int] = {}

        # Worker threads leave word here instead of touching Tk. Calling
        # .after() from another thread happens to work most of the time and is
        # not allowed to: Tk belongs to the thread that created it, and the one
        # time it does not work is a crash inside the interpreter rather than an
        # exception anybody can catch.
        self._from_workers: queue.Queue = queue.Queue()

        self._build()
        self.refresh(initial=True)
        self.after(REFRESH_MS, self._tick)
        self.after(200, self._carrier_tick)
        self.after(400, self._colony_tick)
        self.after(1500, self._update_tick)

    # -- layout ----------------------------------------------------------

    def _build(self) -> None:
        top = ttk.Frame(self, padding=(12, 10, 12, 6))
        top.pack(fill="x")

        ttk.Label(top, text="Construction site").pack(side="left")
        self.depot_box = ttk.Combobox(top, state="readonly", width=52)
        self.depot_box.pack(side="left", padx=(8, 12))
        self.depot_box.bind("<<ComboboxSelected>>", lambda _e: self.render())

        ttk.Checkbutton(top, text="Follow the journal", variable=self.auto).pack(side="right")

        # Only ever shown when there is genuinely something newer. A control
        # that says "you are current" is noise on every launch for the sake of
        # one moment a month.
        self.update_button = ttk.Button(top, text="", command=self.apply_update)
        self.update_button.pack(side="right", padx=(0, 8))
        self.update_button.pack_forget()
        ttk.Button(top, text="Refresh", command=lambda: self.refresh()).pack(side="right", padx=(0, 8))

        head = ttk.Frame(self, padding=(12, 0, 12, 8))
        head.pack(fill="x")

        self.progress = ttk.Progressbar(head, mode="determinate", maximum=1000)
        self.progress.pack(fill="x")
        self.summary = ttk.Label(head, text="", padding=(0, 6, 0, 0))
        self.summary.pack(anchor="w")

        # Who else is on this build. Hidden entirely when nobody is sharing,
        # rather than sitting there empty on a solo haul.
        self.crew = ttk.Label(head, text="", padding=(0, 2, 0, 0), foreground="#9aa4b2")
        self.crew.pack(anchor="w")

        mid = ttk.Frame(self, padding=(12, 0, 12, 6))
        mid.pack(fill="both", expand=True)

        columns = ("commodity", "needed", "delivered", "remaining", "hold", "carrier", "group", "here", "loads")
        headings = {
            "commodity": ("Commodity", 260, "w"),
            "needed": ("Needed", 90, "e"),
            "delivered": ("Delivered", 90, "e"),
            # Not what the site is still short of -- what you are still short
            # of, which is the number that decides what to go and buy. What is
            # in the hold or on the carrier has already been bought.
            "remaining": ("To buy", 100, "e"),
            "hold": ("In hold", 90, "e"),
            "carrier": ("On carrier", 95, "e"),
            "group": ("Others have", 100, "e"),
            "here": ("Sold here", 95, "e"),
            "loads": ("Loads", 70, "e"),
        }

        self.tree = ttk.Treeview(mid, columns=columns, show="headings", selectmode="browse")
        for key in columns:
            text, width, anchor = headings[key]
            self.tree.heading(key, text=text, command=lambda k=key: self._sort_by(k))
            # Commodity is the only stretching column, which meant it was also
            # the only one that shrank -- narrow the window and the numbers kept
            # their width while the names became "Medical Diagnosti". A floor
            # stops that: the table scrolls sideways instead.
            self.tree.column(
                key, width=width, anchor=anchor,
                minwidth=200 if key == "commodity" else width,
                stretch=(key == "commodity"),
            )

        scroll = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        across = ttk.Scrollbar(mid, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=scroll.set, xscrollcommand=across.set)

        # Grid rather than pack: the horizontal bar belongs under the table and
        # not under the vertical one.
        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        across.grid(row=1, column=0, sticky="we")
        mid.rowconfigure(0, weight=1)
        mid.columnconfigure(0, weight=1)

        # Carrying some of it is the one thing worth seeing without reading, so
        # it is a colour rather than another column to scan.
        self.tree.tag_configure("carrying", background="#1f3d2b", foreground="#b7f5cd")
        self.tree.tag_configure("done", foreground="#6b7280")
        # Stocked on the carrier but not in the ship: a shorter trip than
        # buying it, and worth a different colour from having it already.
        self.tree.tag_configure("stocked", background="#2a3350", foreground="#c7d2fe")
        # Buyable at the market last opened. Lowest priority of the three,
        # because it is the only one that still costs a purchase.
        self.tree.tag_configure("available", background="#3d3320", foreground="#fde68a")
        # Somebody else on the build is already carrying this. Distinct from the
        # rest because the action it implies is "do not buy any", not "buy".
        self.tree.tag_configure("shared", background="#3a2740", foreground="#f0c4ff")

        bottom = ttk.Frame(self, padding=(12, 0, 12, 12))
        bottom.pack(fill="x")

        ttk.Label(bottom, text="Cargo capacity").pack(side="left")
        ttk.Entry(bottom, textvariable=self.capacity, width=7).pack(side="left", padx=(6, 4))
        ttk.Label(bottom, text="t").pack(side="left")
        self.capacity.trace_add("write", lambda *_: self.render())

        ttk.Checkbutton(bottom, text="Hide delivered", variable=self.hide_done,
                        command=self.render).pack(side="left", padx=(16, 0))

        ttk.Button(bottom, text="Copy list", command=self.copy_list).pack(side="right")
        ttk.Button(bottom, text="Carrier…", command=self.edit_carrier).pack(side="right", padx=(0, 8))
        self.invite_button = ttk.Button(bottom, text="Invite…", command=self.invite)
        self.invite_button.pack(side="right", padx=(0, 8))
        self.status = ttk.Label(bottom, text="", foreground="#9aa4b2")
        self.status.pack(side="right", padx=(0, 12))

    # -- data ------------------------------------------------------------

    def refresh(self, initial: bool = False) -> None:
        if not os.path.isdir(self.journals.directory):
            self.summary.configure(
                text=f"No journal folder at {self.journals.directory}. "
                     f"Set JOURNAL_DIR if the game writes somewhere else."
            )
            return

        self.journals.scan()

        if initial and self.journals.cargo_capacity and not self.capacity.get():
            self.capacity.set(str(self.journals.cargo_capacity))

        # Unfinished first, then whichever was seen most recently: the one being
        # worked on is almost always the one wanted, and a finished site is kept
        # only so its manifest can still be looked at.
        depots = sorted(
            self.journals.depots.values(),
            key=lambda d: (d.complete, d.timestamp),
            reverse=False,
        )
        depots.sort(key=lambda d: (d.complete, -_ts_key(d.timestamp)))

        previous = self.depot_ids[self.depot_box.current()] if self.depot_ids and self.depot_box.current() >= 0 else None
        self.depot_ids = [d.market_id for d in depots]
        self.depot_box.configure(values=[d.label for d in depots])

        if self.depot_ids:
            index = self.depot_ids.index(previous) if previous in self.depot_ids else 0
            self.depot_box.current(index)

        self.render()

    def effective_depot(self) -> Depot | None:
        """
        The freshest manifest for the selected build, whoever read it.

        The point of sharing is that one person docking updates the site for
        everybody. That only works if the figures actually shown come from the
        newest reading rather than from this machine's own last visit -- which
        is what they did at first, so somebody else delivering four thousand
        tonnes changed nothing on anyone's screen but their own.

        Two cases, and they resolve the same way. If the board has read the site
        more recently than we have, its manifest is used. If we have never
        docked there at all -- which is every hauler who joined on a token --
        there is nothing local to fall back to and the board's is all there is.
        """
        local = self.current_depot()
        pooled = self.colony.needs
        if not pooled:
            return local

        # Only if the board is talking about the build on screen. Choosing a
        # different site in the dropdown leaves the previous one's shared view
        # in hand for a tick or two, and showing one site's requirements under
        # another's name would be worse than showing nothing new.
        try:
            shared_id = int(self.colony.site.get("marketId"))
        except (TypeError, ValueError):
            return local
        if local is not None and shared_id != local.market_id:
            return local

        board_at = journal_time(str(self.colony.site.get("readAt") or ""))
        if local is not None and board_at <= (local.timestamp or ""):
            return local

        site = self.colony.site
        return Depot(
            market_id=int(site.get("marketId") or (local.market_id if local else 0)),
            progress=float(site.get("progress") or 0.0),
            complete=bool(site.get("complete")),
            failed=bool(site.get("failed")),
            timestamp=board_at,
            # Rebuilt in the journal's own shape, so everything downstream --
            # the table, the sorting, the shopping list -- carries on unaware
            # that this reading came from somebody else's evening.
            resources=[
                {
                    "Name": row.get("commodity"),
                    "Name_Localised": row.get("name"),
                    "RequiredAmount": int(row.get("required", 0)),
                    "ProvidedAmount": int(row.get("provided", 0)),
                }
                for row in pooled
            ],
            station=(local.station if local else site.get("name")),
            system=(local.system if local else site.get("system")),
        )

    def current_depot(self) -> Depot | None:
        index = self.depot_box.current()
        if index < 0 or index >= len(self.depot_ids):
            return None
        return self.journals.depots.get(self.depot_ids[index])

    def capacity_value(self) -> int:
        try:
            value = int(float(self.capacity.get()))
        except (TypeError, ValueError):
            return 0
        return max(0, value)

    def render(self) -> None:
        self.tree.delete(*self.tree.get_children())
        depot = self.effective_depot()

        if depot is None:
            self.progress.configure(value=0)
            self.summary.configure(
                text="No construction site in the journals yet. Dock at one once — the game writes "
                     "the full manifest the moment its panel appears, and it will show up here."
            )
            self.status.configure(text="")
            return

        # Read once per render, not once per comparison: sorting by the hold
        # column would otherwise open Cargo.json on every pair the sort touches.
        held = self._held = self.journals.cargo()
        aboard = self._aboard = self.carrier.hold(self.journals)
        market = self._market = self.journals.market()
        pooled = self.colony.by_commodity() if self.colony.needs else {}
        capacity = self.capacity_value()

        rows = depot.resources if not self.hide_done.get() else depot.outstanding
        rows = sorted(rows, key=self._sort_key, reverse=self.sort_reverse)

        for resource in rows:
            name = commodity_name(resource)
            need = int(resource.get("RequiredAmount", 0))
            got = int(resource.get("ProvidedAmount", 0))
            left = Depot.remaining(resource)
            self._symbol_for[name] = commodity_key(resource)
            carrying = held.get(name, 0)
            stocked = aboard.get(name, 0)
            for_sale = market.has(name) if market else 0

            # What everyone else is holding, taken out of the group total so it
            # adds up with the two columns beside it rather than including them.
            shared = pooled.get(commodity_key(resource))
            others = 0
            if shared:
                total = int(shared["held"]["ship"]) + int(shared["held"]["carrier"])
                others = max(0, total - carrying - stocked)
            self._others[name] = others
            # Cargo already yours, wherever it is sitting. It still has to be
            # flown to the site -- that is what Loads counts -- but it does not
            # have to be bought again.
            to_buy = max(0, left - carrying - stocked - others)

            # In descending order of how little work is left to do: already in
            # the hold, already on the carrier, or merely purchasable here.
            tags = ()
            if left == 0:
                tags = ("done",)
            elif carrying > 0:
                tags = ("carrying",)
            elif stocked > 0:
                tags = ("stocked",)
            elif others > 0:
                tags = ("shared",)
            elif for_sale > 0:
                tags = ("available",)

            self.tree.insert("", "end", tags=tags, values=(
                name,
                f"{need:,}",
                f"{got:,}",
                f"{to_buy:,}" if to_buy else "—",
                f"{carrying:,}" if carrying else "",
                f"{stocked:,}" if stocked else "",
                f"{others:,}" if others else "",
                f"{for_sale:,}" if for_sale else "",
                f"{math.ceil(left / capacity):,}" if capacity and left else "",
            ))

        self.progress.configure(value=int(depot.progress * 1000))

        left_total = depot.remaining_total
        deliverable = sum(min(held.get(commodity_name(r), 0), Depot.remaining(r))
                          for r in depot.outstanding)

        parts = [f"{depot.progress * 100:.1f}% built"]
        if depot.failed:
            parts.append("FAILED")
        elif depot.complete:
            parts.append("complete")
        else:
            kinds = len(depot.outstanding)
            parts.append(f"{left_total:,} t to go across {kinds} "
                         f"{'commodity' if kinds == 1 else 'commodities'}")

            # The two figures answer different questions and both are worth
            # having: what the site is short of decides how much flying is left,
            # what you are short of decides what to go and buy.
            buy_total = sum(self._to_buy(r) for r in depot.outstanding)
            if buy_total != left_total:
                parts.append(f"{buy_total:,} t still to buy")

            if capacity:
                parts.append(f"{math.ceil(left_total / capacity):,} loads at {capacity} t")
            if deliverable:
                parts.append(f"{deliverable:,} t of it in your hold now")
            stockpiled = sum(min(aboard.get(commodity_name(r), 0), Depot.remaining(r))
                             for r in depot.outstanding)
            if stockpiled:
                where = self.carrier.callsign or "the carrier"
                parts.append(f"{stockpiled:,} t already on {where}")

            if market is not None:
                # Capped at what is still wanted: a station holding a million
                # tonnes of scrap is not offering a million tonnes of progress.
                buyable = sum(min(market.has(commodity_name(r)), Depot.remaining(r))
                              for r in depot.outstanding)
                if buyable:
                    parts.append(f"{buyable:,} t buyable at {market.station}")

        self.summary.configure(text="   ·   ".join(parts))

        # Who else is on this build, and which of them are reporting now.
        # Presence is a timestamp question rather than a connection one: a
        # planner posts every fifteen seconds and simply stops when it is shut.
        if self.colony.error:
            self.crew.configure(text=f"sharing: {self.colony.error}")
        elif not self.colony.configured(self.config):
            self.crew.configure(text="")
        elif not self.colony.haulers:
            self.crew.configure(text="sharing — nobody else has reported yet")
        else:
            people = self.colony.present()
            live = sum(1 for _, here, _ in people if here)
            shown = ", ".join(
                f"{'● ' if here else '○ '}{name}" + (f" [{carrier}]" if carrier else "")
                for name, here, carrier in people
            )
            self.crew.configure(
                text=f"{live} of {len(people)} hauling now   ·   {shown}")

        if self.updater.available():
            self.update_button.configure(text=f"update to {self.updater.latest}", state="normal")
            self.update_button.pack(side="right", padx=(0, 8))
        else:
            self.update_button.pack_forget()

        # There is nobody to invite to a build that is not being shared.
        self.invite_button.state(
            ["!disabled"] if self.colony.configured(self.config) else ["disabled"])

        # The status line is the only place the carrier link can report itself,
        # and a silent failure there would look like an empty hold.
        bits = []

        # The market first, because it is the only line that can be about
        # somewhere you are not. Market.json is written when a commodities
        # screen is opened, so it may well describe the last station rather than
        # this one -- it is named for that reason, and flagged when the journal
        # says you are docked somewhere else.
        if market is not None:
            wanted = {commodity_name(r) for r in depot.outstanding}
            sells = sorted(wanted & set(market.stock))
            here = self.journals.docked_at
            where = f"{market.station} sells {len(sells)}" if sells else f"{market.station} sells none"
            if here is not None and here != market.market_id:
                where += " (you are docked elsewhere)"
            elif here is None:
                where += " (last market opened)"
            bits.append(where)

        if depot.timestamp:
            local = self.current_depot()
            whose = "" if (local is not None and depot.timestamp == local.timestamp) else " by the crew"
            bits.append(f"site read {depot.timestamp[:16].replace('T', ' ')}Z{whose}")
        if self.carrier.error:
            bits.append(self.carrier.error)
        elif self.carrier.cargo_at:
            moved = self.journals.moves_since(self.carrier.market_id or 0, self.carrier.cargo_at)
            net = sum(moved.values())
            bits.append(f"carrier {self.carrier.cargo_at[:16].replace('T', ' ')}Z"
                        + (f" {net:+,} t since" if net else ""))
        self.status.configure(text="   ·   ".join(bits))

    # -- actions ---------------------------------------------------------

    def _to_buy(self, resource: dict) -> int:
        """What is still short, after what is already in the hold or aboard."""
        name = commodity_name(resource)
        return max(0, Depot.remaining(resource)
                   - self._held.get(name, 0)
                   - self._aboard.get(name, 0))

    def _sort_key(self, resource: dict):
        name = commodity_name(resource)
        return {
            "commodity": name.lower(),
            "needed": int(resource.get("RequiredAmount", 0)),
            "delivered": int(resource.get("ProvidedAmount", 0)),
            "remaining": self._to_buy(resource),
            "hold": self._held.get(name, 0),
            "carrier": self._aboard.get(name, 0),
            "group": self._others.get(name, 0),
            "here": self._market.has(name) if self._market else 0,
            "loads": Depot.remaining(resource),
        }[self.sort_column]

    def _sort_by(self, column: str) -> None:
        if column == self.sort_column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            # Names read best A-Z; every other column is a quantity, and the
            # large ones are the ones being looked for.
            self.sort_reverse = column != "commodity"
        self.render()

    def copy_list(self) -> None:
        depot = self.effective_depot()
        if depot is None or not depot.outstanding:
            return

        # A shopping list, so it lists what is still to be bought rather than
        # what the site is short of -- otherwise it would send you out for
        # cargo already sitting on your own carrier.
        wanted = [(commodity_name(r), self._to_buy(r)) for r in depot.outstanding]
        wanted = sorted(((n, q) for n, q in wanted if q > 0), key=lambda item: -item[1])

        if not wanted:
            self.status.configure(text="nothing left to buy — it is all aboard already")
            return

        total = sum(q for _, q in wanted)
        lines = [f"{depot.label} — {total:,} t to buy"]
        lines += [f"{name}\t{qty}" for name, qty in wanted]

        self.clipboard_clear()
        self.clipboard_append("\n".join(lines))
        kinds = len(wanted)
        self.status.configure(
            text=f"copied {kinds} {'commodity' if kinds == 1 else 'commodities'}")

    def edit_carrier(self) -> None:
        """
        Where the board lives, and which carrier to ask about.

        Three fields and no more. The key is typed once and kept out of the
        project folder; see config_path.
        """
        dialog = tk.Toplevel(self)
        dialog.title("Carrier Ops")
        dialog.transient(self)
        dialog.resizable(False, False)

        frame = ttk.Frame(dialog, padding=14)
        frame.pack(fill="both", expand=True)

        # Defaults go in the box, not under it. Only the two fields nobody can
        # guess are left empty.
        fields = {
            "board_url": ("Board address", DEFAULT_BOARD, "", 42, False),
            "api_key": ("API key or build token", "", "an account key, or an fcb_… invitation", 42, True),
            "carrier": ("Carrier", "", "callsign, e.g. V4H-84Q", 20, False),
        }
        share = tk.IntVar(value=1 if self.config.get("share") else 0)
        entries: dict[str, tk.StringVar] = {}

        for row, (key, (label, default, hint, width, secret)) in enumerate(fields.items()):
            ttk.Label(frame, text=label).grid(row=row * 2, column=0, sticky="w", pady=(0 if row == 0 else 8, 2))
            var = tk.StringVar(value=str(self.config.get(key) or default))
            entry = ttk.Entry(frame, textvariable=var, width=width, show="•" if secret else "")
            entry.grid(row=row * 2 + 1, column=0, sticky="we")
            ttk.Label(frame, text=hint, foreground="#9aa4b2").grid(row=row * 2 + 2, column=0, sticky="w")
            entries[key] = var

        ttk.Checkbutton(
            frame, text="Share this build with the others hauling to it", variable=share,
        ).grid(row=90, column=0, sticky="w", pady=(14, 0))

        note = ttk.Label(
            frame, wraplength=340, foreground="#9aa4b2",
            text="The board supplies the carrier manifest; transfers and carrier-market trades since "
                 "then are added from your journal. Sharing posts what you can see of the "
                 "construction site every fifteen seconds and reads back what everybody else can — "
                 "the site's own figures, and who is carrying what.",
        )
        note.grid(row=99, column=0, sticky="w", pady=(8, 10))

        buttons = ttk.Frame(frame)
        buttons.grid(row=100, column=0, sticky="e")

        def commit() -> None:
            for key, var in entries.items():
                self.config[key] = var.get().strip()
            self.config["share"] = bool(share.get())
            saved = save_config(self.config)
            # Both links start again from nothing: the key or the carrier may
            # have changed under them, and a stale manifest from the previous
            # settings would be worse than an empty one.
            self.carrier = CarrierLink()
            self.colony = ColonyLink()
            dialog.destroy()
            self.status.configure(
                text="saved" if saved else f"could not write {config_path()}")
            self._carrier_tick_once()

        ttk.Button(buttons, text="Save", command=commit).pack(side="right")
        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right", padx=(0, 8))

        dialog.bind("<Return>", lambda _e: commit())
        dialog.bind("<Escape>", lambda _e: dialog.destroy())
        dialog.grab_set()

    def _build_report(self) -> dict | None:
        """
        This machine's whole position on the selected build.

        Sent in full every time rather than as changes since last time. It is a
        few dozen numbers, and a report that stands alone cannot drift out of
        step with the board the way a stream of deltas can -- which matters more
        here than the bytes, because the other haulers are reading it.
        """
        # Read the journal first, so everything in this report describes the
        # same instant.
        #
        # Delivering empties the ship and updates the site in the same second,
        # but those reach us by different routes -- Cargo.json is read fresh
        # every time, while the manifest comes from the last journal scan, on
        # its own timer. Report in between and the cargo has left the hold while
        # the site has not yet been credited with it, so for one cycle the
        # tonnage exists nowhere at all and the crew watches their own delivery
        # vanish. Rescanning here costs about thirty milliseconds and removes
        # the gap rather than narrowing it.
        self.journals.scan()

        depot = self.current_depot()

        # Somebody who joined on an invitation and has not yet flown there has
        # no reading of their own, and used to report nothing at all -- so their
        # hold never reached the crew and they never appeared in the list of who
        # was hauling. They have a position worth pooling long before they have
        # a manifest, so the build being shared is enough to report against.
        market_id = depot.market_id if depot is not None else None
        if market_id is None and self.colony.site:
            try:
                market_id = int(self.colony.site.get("marketId"))
            except (TypeError, ValueError):
                market_id = None
        if market_id is None:
            return None

        held = self.journals.cargo()
        aboard = self.carrier.hold(self.journals)
        delivered = self.journals.delivered.get(market_id, {})

        # Keyed by symbol, since that is the one name every client agrees on.
        # Display names are carried for the manifest only, so the board has
        # something readable for a commodity nobody else has seen yet.
        symbols: dict[str, dict[str, int]] = {}

        def note(symbol: str, field: str, amount: int) -> None:
            if symbol and amount > 0:
                symbols.setdefault(symbol, {})[field] = amount

        for name, qty in held.items():
            note(commodity_key({"Name": self._symbol_for.get(name, name)}), "ship", qty)
        for name, qty in aboard.items():
            note(commodity_key({"Name": self._symbol_for.get(name, name)}), "carrier", qty)
        for symbol, qty in delivered.items():
            note(symbol, "delivered", qty)

        report = {
            "marketId": market_id,
            "name": pretty_station(depot.station) if depot is not None and depot.station else None,
            "system": depot.system if depot is not None else None,
            "cmdr": self.journals.cmdr,
            "carrier": self.carrier.callsign or (self.config.get("carrier") or None),
            "ship": self.journals.ship,
            "cargoCapacity": self.capacity_value() or None,
            "stock": [
                {"commodity": symbol, **counts} for symbol, counts in symbols.items()
            ],
        }

        # The manifest only goes up if this commander actually read it. A
        # planner that has never docked has nothing to say about what the site
        # wants, and must not overwrite the reading of somebody who has.
        if depot is not None and depot.resources and depot.timestamp:
            report.update({
                "readAt": depot.timestamp,
                "progress": depot.progress,
                "complete": depot.complete,
                "failed": depot.failed,
                "needs": [
                    {
                        "commodity": commodity_key(r),
                        "name": commodity_name(r),
                        "required": int(r.get("RequiredAmount", 0)),
                        "provided": int(r.get("ProvidedAmount", 0)),
                        "payment": int(r.get("Payment", 0) or 0),
                    }
                    for r in depot.resources
                ],
            })

        return report

    def _update_tick(self) -> None:
        self.updater.check_async(self.config, lambda: self._from_workers.put("render"))
        self.after(UPDATE_CHECK_MS, self._update_tick)

    def apply_update(self) -> None:
        """Fetch the new planner, write it over this one, and start it."""
        if not self.updater.available():
            return
        self.update_button.configure(text="updating…", state="disabled")
        self.status.configure(text="downloading the new planner…")

        def work() -> None:
            ok, message = self.updater.apply(self.config)
            self._from_workers.put(("update", ok, message))

        threading.Thread(target=work, name="planner update", daemon=True).start()

    def _colony_tick(self) -> None:
        if self.colony.configured(self.config):
            report = self._build_report()
            if report is not None:
                self.colony.sync_async(
                    self.config, report, lambda: self._from_workers.put("render"))
        # Re-read each time rather than scheduled once: an interval changed in
        # the admin panel then takes effect on the following tick, without
        # anybody restarting anything.
        self.after(self._interval("reportSeconds", COLONY_REFRESH_MS), self._colony_tick)

    def invite(self) -> None:
        """
        Mint an invitation to this build and put it on the clipboard.

        Handed over in a Discord message. It carries no account, works on this
        one construction site and nothing else on the board, and can be revoked
        without disturbing anybody else on the run -- which is what makes it
        reasonable to give one to somebody who turned up yesterday.
        """
        depot = self.effective_depot()
        if depot is None or not self.colony.configured(self.config):
            self.status.configure(text="share a build first, then invite people to it")
            return

        def work() -> None:
            base = (self.config.get("board_url") or DEFAULT_BOARD).strip().rstrip("/")
            if "://" not in base:
                base = "https://" + base
            url = (base + "/api.php?action=colony_invite&marketId=" + str(depot.market_id))
            request = urllib.request.Request(
                url, data=b"", method="POST",
                headers={"X-API-Key": self.config["api_key"],
                         "User-Agent": f"ColonyPlanner/{VERSION}"},
            )
            try:
                with urllib.request.urlopen(request, timeout=15) as response:
                    data = json.load(response)
                token = data.get("token")
            except Exception as err:                      # noqa: BLE001
                self._from_workers.put(("invite", None, f"invite failed: {err}"))
                return

            self._from_workers.put((
                "invite", token,
                # Said out loud because the board keeps only the hash: there is
                # no screen anywhere that can show it again.
                "invitation copied — it cannot be shown again" if token
                else str(data.get("error", "no token returned")),
            ))

        threading.Thread(target=work, name="colony invite", daemon=True).start()

    def _carrier_tick_once(self) -> None:
        if self.carrier.configured(self.config):
            self.carrier.fetch_async(self.config, lambda: self._from_workers.put("render"))
        else:
            self.render()

    def show_invite(self, token: str) -> None:
        """
        Put the new invitation in front of somebody, not in the status line.

        A line of small text in a corner was where this went first, and it was
        the wrong place: the board keeps only a hash, so this is the one moment
        the token exists anywhere it can be read. If it is missed it is gone,
        and the only remedy is to mint another and wonder what became of the
        last one. So it gets a window, the text is selected ready to copy again,
        and it says plainly that there is no second chance.
        """
        dialog = tk.Toplevel(self)
        dialog.title("Invitation")
        dialog.transient(self)
        dialog.resizable(False, False)

        frame = ttk.Frame(dialog, padding=16)
        frame.pack(fill="both", expand=True)

        depot = self.effective_depot()
        ttk.Label(
            frame, font=("TkDefaultFont", 10, "bold"),
            text=f"Invitation to {depot.label if depot else 'this build'}",
        ).pack(anchor="w")

        ttk.Label(
            frame, foreground="#7ee787", padding=(0, 6, 0, 8),
            text="Copied to your clipboard — paste it to whoever is hauling.",
        ).pack(anchor="w")

        entry = ttk.Entry(frame, width=52, font=("TkFixedFont", 9))
        entry.insert(0, token)
        entry.pack(fill="x")
        entry.selection_range(0, "end")
        entry.focus_set()
        # Readable and selectable, but not editable: what is shown has to stay
        # the thing that was actually minted.
        entry.configure(state="readonly")

        ttk.Label(
            frame, wraplength=420, foreground="#9aa4b2", padding=(0, 10, 0, 12),
            text="They paste it into the API key box of their own planner. It works on this "
                 "construction site and nothing else — no carrier, no journals, no other build. "
                 "Only its hash is stored here, so this window is the last time it can be read; "
                 "mint another if it is lost.",
        ).pack(anchor="w")

        buttons = ttk.Frame(frame)
        buttons.pack(anchor="e")

        def copy_again() -> None:
            self.clipboard_clear()
            self.clipboard_append(token)
            entry.selection_range(0, "end")

        ttk.Button(buttons, text="Copy again", command=copy_again).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Done", command=dialog.destroy).pack(side="right")

        self.clipboard_clear()
        self.clipboard_append(token)
        dialog.bind("<Escape>", lambda _e: dialog.destroy())
        dialog.bind("<Return>", lambda _e: dialog.destroy())
        dialog.grab_set()
        self.status.configure(text="invitation minted")

    def _interval(self, name: str, fallback_ms: int) -> int:
        """
        How long until the next run of a loop, in milliseconds.

        The board's answer if it has given one, this build's constant if not.
        Clamped either way: a bad number here would either hammer the board from
        every planner at once or stop them talking altogether, and neither
        should be reachable by editing a row.
        """
        seconds = self.colony.settings.get(name)
        if not isinstance(seconds, int) or seconds <= 0:
            return fallback_ms
        return max(1000, min(3_600_000, seconds * 1000))

    def _drain(self) -> None:
        """Whatever the workers left, applied on the thread that owns the window."""
        redraw = False
        while True:
            try:
                item = self._from_workers.get_nowait()
            except queue.Empty:
                break
            if item == "render":
                redraw = True
            elif isinstance(item, tuple) and item[0] == "update":
                _, ok, message = item
                self.status.configure(text=message)
                if ok:
                    # Restart rather than offer to: the point of one click is
                    # that it is one click, and the files on disk are already
                    # the new ones.
                    self.updater.relaunch()
                    self.destroy()
                    return
                self.update_button.configure(state="!disabled")
            elif isinstance(item, tuple) and item[0] == "invite":
                _, token, message = item
                if token:
                    self.show_invite(token)
                else:
                    self.status.configure(text=message)
        if redraw:
            self.render()

    def _tick(self) -> None:
        self._drain()
        if self.auto.get():
            try:
                self.refresh()
            except Exception as err:                      # noqa: BLE001
                # A refresh failing must not take the window with it: the
                # journal is being written by another process and a half-flushed
                # line is a normal thing to meet.
                self.status.configure(text=f"refresh failed: {err}")
        self.after(self._interval("journalSeconds", REFRESH_MS), self._tick)

    def _carrier_tick(self) -> None:
        """Ask the board, on its own much slower clock."""
        if self.carrier.configured(self.config):
            self.carrier.fetch_async(
                self.config,
                lambda: self._from_workers.put("render"),
            )
        self.after(self._interval("carrierSeconds", CARRIER_REFRESH_MS), self._carrier_tick)


def _ts_key(timestamp: str) -> float:
    """Sortable, without pulling in a date parser for an ISO string."""
    return float("".join(c for c in timestamp if c.isdigit()) or 0)


def main() -> int:
    try:
        app = App()
    except tk.TclError as err:
        print(f"{APP_NAME}: no display available ({err})", file=sys.stderr)
        return 1
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
